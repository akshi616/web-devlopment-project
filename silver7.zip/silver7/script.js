
document.addEventListener('DOMContentLoaded',function()
{
    document.getElementById('submitButton').addEventListener('click',function()
{
    alert('successfully submitted')
});
});